﻿namespace HierarchicalInheritance.Models;

public class Animal
{
    public void Eat()
    {
        Console.WriteLine("eating...");
    }
}
