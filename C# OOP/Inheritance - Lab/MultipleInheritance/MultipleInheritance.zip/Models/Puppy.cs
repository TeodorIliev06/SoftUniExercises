﻿namespace MultipleInheritance.Models;

class Puppy : Dog
{
    public void Weep()
    {
        Console.WriteLine("weeping...");
    }
}
