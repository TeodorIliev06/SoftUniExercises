﻿namespace MilitaryElite.Models.Enums
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
