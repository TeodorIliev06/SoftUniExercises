﻿namespace Telephony.Models.Interfaces;

public interface IBrowse
{
    void Browse(string website);
}
