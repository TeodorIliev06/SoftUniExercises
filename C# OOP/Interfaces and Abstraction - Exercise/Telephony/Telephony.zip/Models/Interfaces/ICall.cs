﻿namespace Telephony.Models.Interfaces;

public interface ICall
{
    void Call(string phoneNumber);
}
