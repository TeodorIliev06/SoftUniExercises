﻿namespace Cars.Interfaces;

public interface IElectricCar
{
    int Battery { get; set; }
}
