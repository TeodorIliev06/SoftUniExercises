﻿namespace SoftUni.Data
{
    internal static class Configuration
    {
        internal const string ConnectionString = "Server=.;Database=SoftUni;Integrated Security=True;";
    }
}
