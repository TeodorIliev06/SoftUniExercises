﻿namespace P01_StudentSystem.Data
{
    internal class Configuration
    {
        internal const string ConnectionString = "Server=.;Database=StudentSystem;Integrated Security=True";
    }
}
