﻿namespace P02_FootballBetting.Data.Configurations
{
    internal class ServerConfiguration
    {
        internal const string ConnectionString = "Server=.;Database=StudentSystem;Integrated Security=True";
    }
}
