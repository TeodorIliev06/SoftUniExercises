﻿namespace P01_HospitalDatabase.Data.Configurations
{
    public class ServerConfiguration
    {
        public const string ConnectionString = "Server=.;Database=StudentSystem;Integrated Security=True";
    }
}
