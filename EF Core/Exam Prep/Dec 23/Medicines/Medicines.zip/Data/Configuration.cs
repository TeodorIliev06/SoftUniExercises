﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Medicines;Integrated Security=True;";
    }
}
