﻿namespace SocialNetwork.Data.Models.Enums
{
    public enum MessageStatus
    {
        Sent = 0,
        Delivered,
        Seen,
        Failed
    }
}
