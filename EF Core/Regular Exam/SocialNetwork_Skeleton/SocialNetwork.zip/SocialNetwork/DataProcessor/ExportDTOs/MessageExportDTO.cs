﻿namespace SocialNetwork.DataProcessor.ExportDTOs
{
    public class MessageExportDTO
    {
        public string Content { get; set; }

        public string SentAt { get; set; }

        public int Status { get; set; }

        public string SenderUsername { get; set; }
    }
}
