async function lockedProfile() {
    const ICON_PROFILE_PATH = './iconProfile2.png';
    const BASE_URL = 'http://localhost:3030/jsonstore/advanced/profiles';
    const mainElement = document.getElementById('main');

    try {
        const response = await fetch(BASE_URL);
        if (!response.ok) {
            throw new Error('Error fetching profiles');
        }

        const profiles = await response.json();
        const profileArray = Object.values(profiles);

        // Clear existing profiles (if any)
        mainElement.innerHTML = '';

        profileArray.forEach((profile, index) => {
            // Create a new profile card based on the template provided
            const profileDiv = document.createElement('div');
            profileDiv.className = 'profile';

            const imgEl = document.createElement('img');
            imgEl.setAttribute('src', ICON_PROFILE_PATH);
            imgEl.classList.add('userIcon');

            const lockLabel = document.createElement('label');
            lockLabel.textContent = 'Lock';
            const lockRadioBtn = document.createElement('input');
            lockRadioBtn.type = 'radio';
            lockRadioBtn.name = `user${index + 1}Locked`;
            lockRadioBtn.value = 'lock';
            lockRadioBtn.checked = true;

            const unlockLabel = document.createElement('label');
            unlockLabel.textContent = 'Unlock';
            const unlockRadioBtn = document.createElement('input');
            unlockRadioBtn.type = 'radio';
            unlockRadioBtn.name = `user${index + 1}Locked`;
            unlockRadioBtn.value = 'unlock';

            const usernameLabel = document.createElement('label');
            usernameLabel.textContent = 'Username';
            const usernameInput = document.createElement('input');
            usernameInput.type = 'text';
            usernameInput.name = `user${index + 1}Username`;
            usernameInput.value = profile.username;
            usernameInput.disabled = true;
            usernameInput.readOnly = true;

            // Hidden fields div
            const hiddenFieldsDiv = document.createElement('div');
            hiddenFieldsDiv.className = 'hiddenFields';
            hiddenFieldsDiv.style.display = 'none';

            const hr = document.createElement('hr');

            const emailLabel = document.createElement('label');
            emailLabel.textContent = 'Email:';
            const emailInput = document.createElement('input');
            emailInput.type = 'email';
            emailInput.name = `user${index + 1}Email`;
            emailInput.value = profile.email;  // Ensure we set the email correctly
            emailInput.disabled = true;
            emailInput.readOnly = true;

            const ageLabel = document.createElement('label');
            ageLabel.textContent = 'Age:';
            const ageInput = document.createElement('input');
            ageInput.type = 'text';  // Changed to text for better compatibility
            ageInput.name = `user${index + 1}Age`;
            ageInput.value = profile.age;  // Ensure we set the age correctly
            ageInput.disabled = true;
            ageInput.readOnly = true;

            // Create the "Show more" button
            const showMoreButton = document.createElement('button');
            showMoreButton.textContent = 'Show more';

            // Append all elements to the profile div
            profileDiv.appendChild(imgEl);
            profileDiv.appendChild(lockLabel);
            profileDiv.appendChild(lockRadioBtn);
            profileDiv.appendChild(unlockLabel);
            profileDiv.appendChild(unlockRadioBtn);
            profileDiv.appendChild(document.createElement('br'));
            profileDiv.appendChild(document.createElement('hr'));
            profileDiv.appendChild(usernameLabel);
            profileDiv.appendChild(usernameInput);
            profileDiv.appendChild(hiddenFieldsDiv);
            hiddenFieldsDiv.appendChild(hr);
            hiddenFieldsDiv.appendChild(emailLabel);
            hiddenFieldsDiv.appendChild(emailInput);
            hiddenFieldsDiv.appendChild(ageLabel);
            hiddenFieldsDiv.appendChild(ageInput);
            profileDiv.appendChild(showMoreButton);

            // Append the new profile card to the main element
            mainElement.appendChild(profileDiv);

            // Add event listener for the "Show more" button
            showMoreButton.addEventListener('click', () => {
                const lockRadio = profileDiv.querySelector(`input[name="user${index + 1}Locked"]:checked`);
                if (lockRadio.value === 'unlock') {
                    hiddenFieldsDiv.style.display = hiddenFieldsDiv.style.display === 'none' ? 'block' : 'none';
                    showMoreButton.textContent = showMoreButton.textContent === 'Show more' ? 'Hide it' : 'Show more';
                }
            });

            const lockRadioButtons = profileDiv.querySelectorAll(`input[name="user${index + 1}Locked"]`);
            lockRadioButtons.forEach(radio => {
                radio.addEventListener('change', () => {
                    if (radio.value === 'lock') {
                        hiddenFieldsDiv.style.display = 'none';
                        showMoreButton.textContent = 'Show more';
                    }
                });
            });
        });
    } catch (error) {
        console.error(error);
    }
}

window.onload = lockedProfile;
